package test.api.restfulapi;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentResource {
	
	private StudentDaoService service;
	
	public StudentResource(StudentDaoService service) {
		this.service = service;
	}
	
	// get list of students
	@GetMapping("/fetchstudents")
	public List<Student> retrieveAllStudents(){
		return service.findAll();
	}

	// path variable to get specific student
	@GetMapping("/fetchstudents/{id}")
	public Student retrieveStudent(@PathVariable int id){
		return service.findbyId(id);
	}
	
	// post to create more records; Talent API testing tool; curl statement - google chrome developer
	@PostMapping("/fetchstudents")
	public void createStudent(@RequestBody Student student) {
		service.save(student);
	}
	
	// to delete specific student
	@DeleteMapping("/fetchstudents/{id}")
	public void deleteStudent(@PathVariable int id){
		service.deletebyId(id);
	}
}
