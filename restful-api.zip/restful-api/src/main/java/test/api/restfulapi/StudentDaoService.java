package test.api.restfulapi;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Component;

@Component
public class StudentDaoService {
	// data access object - functional programming 
	
	// static array list
	private static List<Student> students = new ArrayList<>();
	
	private static int studentId = 0;
	
	// manually creating users as needed
	static {
		students.add(new Student(++studentId,"Mikr","Wong","3 A","Singapore"));
	}
	
	// post mapping to create user
	public Student save(Student student) {
		student.setId(++studentId);
		students.add(student);
		return student;
	}

	// pull all records
	public List<Student> findAll(){
		return students;
	}
	
	// to pull specific student/record
	public Student findbyId(int id) {
		// local variable
		Predicate<? super Student> predicate = student -> student.getId().equals(id);
		return students.stream().filter(predicate).findFirst().get();
	}
	
	public void deletebyId(int id) {
		// local variable
		Predicate<? super Student> predicate = student -> student.getId().equals(id);
		students.removeIf(predicate);
	}
	
}
