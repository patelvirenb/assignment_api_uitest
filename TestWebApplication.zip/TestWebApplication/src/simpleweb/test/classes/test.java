package simpleweb.test.classes;

public class test {

}
