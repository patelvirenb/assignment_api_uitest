package simpleweb.test.classes;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import simpleweb.page.classes.HomePageClass;

public class TestClass {
	private WebDriver driver;
	private String baseURL;
	
	@BeforeClass
	@BeforeMethod
	public void setUp() throws Exception {
		
		// Firefox
		// System.setProperty("webdriver.gecko.driver", "/Users/viren.patel1/Desktop/projects/drivers/geckodriver");
		// driver = new FirefoxDriver();
		
		// Google chrome
		System.setProperty("webdriver.chrome.driver", "/Users/viren.patel1/Desktop/projects/drivers/chromedriver");
		driver = new ChromeDriver();
		baseURL = "http://the-internet.herokuapp.com/";
	}

	@Test
	public void test() {
		driver.get(baseURL);
		HomePageClass.clickLinkWithText(driver, "Form Authentication");
	}
	
	@AfterClass
	public void tearDown() throws Exception {
	}
}
