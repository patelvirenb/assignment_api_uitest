package simpleweb.page.classes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePageClass {

	public static WebElement element = null;
	
	public static WebElement userName(WebDriver driver) {
		element = driver.findElement(By.name("username"));
		return element;
	}
	
	public static void clickLinkWithText(WebDriver driver,String text) {
		driver.findElement(By.linkText(text)).click();
	}

}
